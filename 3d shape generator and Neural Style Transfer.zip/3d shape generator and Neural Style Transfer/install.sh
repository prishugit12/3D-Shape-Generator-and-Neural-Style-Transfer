#!/bin/bash

# Quick Start Installation Script
# Installs all dependencies for the three CV projects

echo "========================================"
echo "Visual & Creative AI Projects Installer"
echo "========================================"
echo ""

# Check Python version
python_version=$(python3 --version 2>&1 | awk '{print $2}')
echo "Detected Python version: $python_version"

# Check if pip is installed
if ! command -v pip3 &> /dev/null; then
    echo "Error: pip3 is not installed. Please install it first."
    exit 1
fi

echo ""
echo "Installing dependencies for all three projects..."
echo ""

# Project 1: Neural Style Transfer
echo "📦 Installing Neural Style Transfer dependencies..."
cd neural-style-transfer
pip3 install -r requirements.txt
if [ $? -eq 0 ]; then
    echo "✓ Neural Style Transfer installed successfully"
else
    echo "✗ Error installing Neural Style Transfer dependencies"
fi
cd ..
echo ""

# Project 2: AI Image Generator
echo "📦 Installing AI Image Generator dependencies..."
echo "⚠️  Note: This will download ~5GB model on first run"
cd ai-image-generator
pip3 install -r requirements.txt
if [ $? -eq 0 ]; then
    echo "✓ AI Image Generator installed successfully"
else
    echo "✗ Error installing AI Image Generator dependencies"
fi
cd ..
echo ""

# Project 3: 3D Shape Generator
echo "📦 Installing 3D Shape Generator dependencies..."
cd 3d-shape-generator
pip3 install -r requirements.txt
if [ $? -eq 0 ]; then
    echo "✓ 3D Shape Generator installed successfully"
else
    echo "✗ Error installing 3D Shape Generator dependencies"
fi
cd ..
echo ""

echo "========================================"
echo "Installation Complete! 🎉"
echo "========================================"
echo ""
echo "To run the demos:"
echo ""
echo "1. Neural Style Transfer:"
echo "   cd neural-style-transfer && python3 app.py"
echo ""
echo "2. AI Image Generator:"
echo "   cd ai-image-generator && python3 app.py"
echo ""
echo "3. 3D Shape Generator:"
echo "   cd 3d-shape-generator && python3 app.py"
echo ""
echo "Each demo will be available at http://localhost:7860"
echo ""
echo "For detailed usage, see README.md in each project folder"
echo ""
